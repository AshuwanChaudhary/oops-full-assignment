package gui;

import models.Player;
import models.Question;
import database.QuizManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Frame for playing one round (5 questions)
 * After finishing, opens next round or results
 */
public class RoundFrame extends JFrame {
    
    private Player player;
    private int currentRound;
    private int[] allScores;
    private ArrayList<Question> questions;
    private int currentQuestion = 0;
    
    private JLabel roundLabel;
    private JLabel questionLabel;
    private JRadioButton optA, optB, optC, optD;
    private ButtonGroup group;
    private JButton nextBtn;
    private JLabel progressLabel;
    
    public RoundFrame(Player player, int round, int[] scores) {
        this.player = player;
        this.currentRound = round;
        this.allScores = scores;
        this.questions = new QuizManager().getQuestionsByRound(round);
        
        setTitle("Round " + round + " - " + player.getName().getFullName());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
        showQuestion();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Round header
        roundLabel = new JLabel("ROUND " + currentRound, JLabel.CENTER);
        roundLabel.setFont(new Font("Arial", Font.BOLD, 24));
        roundLabel.setForeground(new Color(70, 130, 180));
        roundLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(roundLabel, BorderLayout.NORTH);
        
        // Center panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        progressLabel = new JLabel("Question 1 of 5");
        progressLabel.setFont(new Font("Arial", Font.BOLD, 16));
        centerPanel.add(progressLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        questionLabel = new JLabel("Question text");
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        centerPanel.add(questionLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Options
        group = new ButtonGroup();
        optA = new JRadioButton("A");
        optB = new JRadioButton("B");
        optC = new JRadioButton("C");
        optD = new JRadioButton("D");
        
        Font optionFont = new Font("Arial", Font.PLAIN, 16);
        optA.setFont(optionFont);
        optB.setFont(optionFont);
        optC.setFont(optionFont);
        optD.setFont(optionFont);
        
        group.add(optA); group.add(optB); group.add(optC); group.add(optD);
        
        centerPanel.add(optA);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(optB);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(optC);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(optD);
        
        add(centerPanel, BorderLayout.CENTER);
        
        // Next button
        nextBtn = new JButton("Next Question");
        nextBtn.setFont(new Font("Arial", Font.BOLD, 18));
        nextBtn.setBackground(new Color(70, 130, 180));
        nextBtn.setForeground(Color.WHITE);
        nextBtn.addActionListener(e -> checkAndNext());
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        bottomPanel.add(nextBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    private void showQuestion() {
        if (currentQuestion < questions.size()) {
            Question q = questions.get(currentQuestion);
            
            progressLabel.setText("Question " + (currentQuestion + 1) + " of 5");
            
            questionLabel.setText("<html><body style='width: 700px'>" + 
                q.getQuestionText() + "</body></html>");
            
            optA.setText("A. " + q.getOptionA());
            optB.setText("B. " + q.getOptionB());
            optC.setText("C. " + q.getOptionC());
            optD.setText("D. " + q.getOptionD());
            
            group.clearSelection();
            
            if (currentQuestion == 4) {
                if (currentRound == 5) {
                    nextBtn.setText("Finish Quiz");
                } else {
                    nextBtn.setText("Next Round");
                }
            }
        } else {
            finishRound();
        }
    }
    
    private void checkAndNext() {
        char answer = ' ';
        if (optA.isSelected()) answer = 'A';
        else if (optB.isSelected()) answer = 'B';
        else if (optC.isSelected()) answer = 'C';
        else if (optD.isSelected()) answer = 'D';
        
        if (answer == ' ') {
            JOptionPane.showMessageDialog(this, "Please select an answer!");
            return;
        }
        
        // Calculate score index in array of 25
        int scoreIndex = (currentRound - 1) * 5 + currentQuestion;
        
        if (questions.get(currentQuestion).isCorrect(answer)) {
            allScores[scoreIndex] = 1;
        } else {
            allScores[scoreIndex] = 0;
        }
        
        currentQuestion++;
        showQuestion();
    }
    
    private void finishRound() {
        int roundScore = 0;
        int start = (currentRound - 1) * 5;
        for (int i = start; i < start + 5; i++) {
            roundScore += allScores[i];
        }
        
        if (currentRound < 5) {
            // Go to next round
            JOptionPane.showMessageDialog(this, 
                "Round " + currentRound + " Complete!\n" +
                "Your score this round: " + roundScore + "/5\n\n" +
                "Click OK to start Round " + (currentRound + 1));
            
            this.dispose();
            new RoundFrame(player, currentRound + 1, allScores).setVisible(true);
        } else {
            // All rounds complete
            finishQuiz();
        }
    }
    
    private void finishQuiz() {
        // Calculate total score
        int totalScore = 0;
        for (int s : allScores) totalScore += s;
        double overall = (double) totalScore / 5;
        
        // Save to database
        QuizManager manager = new QuizManager();
        int playerId = manager.savePlayer(player);
        if (playerId > 0) {
            manager.saveResult(playerId, allScores, overall);
            player.setScores(allScores);
        }
        
        // Show results
        this.dispose();
        new ResultFrame(player, allScores).setVisible(true);
    }
}