package gui;

import models.Player;
import database.QuizManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * Main window showing all results
 */
public class MainFrame extends JFrame {
    
    private JTable table;
    private DefaultTableModel model;
    private QuizManager manager;
    private JTextArea reportArea;
    private JTextField searchField;
    private JTextArea searchResultArea;
    
    public MainFrame() {
        manager = new QuizManager();
        
        setTitle("Quiz Competition - 5 Rounds");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Title
        JLabel title = new JLabel("Quiz Competition Results (5 Rounds)", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(title, BorderLayout.NORTH);
        
        // Top button panel
        JPanel topPanel = new JPanel();
        JButton newPlayerBtn = new JButton("New Player (Start Quiz)");
        newPlayerBtn.setFont(new Font("Arial", Font.BOLD, 16));
        newPlayerBtn.setBackground(new Color(60, 179, 113));
        newPlayerBtn.setForeground(Color.WHITE);
        newPlayerBtn.addActionListener(e -> {
            this.dispose();
            new PlayerSetupFrame().setVisible(true);
        });
        topPanel.add(newPlayerBtn);
        add(topPanel, BorderLayout.NORTH);
        
        // Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Arial", Font.BOLD, 14));
        tabs.addTab("Player Table", createTablePanel());
        tabs.addTab("Search by ID", createSearchPanel());
        tabs.addTab("Statistics", createStatsPanel());
        
        add(tabs, BorderLayout.CENTER);
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        String[] columns = {"ID", "Name", "Level", "Age", "R1", "R2", "R3", "R4", "R5", "Overall"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        
        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> loadData());
        JPanel btnPanel = new JPanel();
        btnPanel.add(refreshBtn);
        panel.add(btnPanel, BorderLayout.SOUTH);
        
        loadData();
        return panel;
    }
    
    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchPanel.add(new JLabel("Enter Player ID:"));
        searchField = new JTextField(10);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchPanel.add(searchField);
        
        JButton searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(70, 130, 180));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.addActionListener(e -> searchPlayer());
        searchPanel.add(searchBtn);
        
        panel.add(searchPanel, BorderLayout.NORTH);
        
        searchResultArea = new JTextArea();
        searchResultArea.setEditable(false);
        searchResultArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        panel.add(new JScrollPane(searchResultArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        
        JButton generateBtn = new JButton("Generate Report");
        generateBtn.setBackground(new Color(70, 130, 180));
        generateBtn.setForeground(Color.WHITE);
        generateBtn.addActionListener(e -> generateReport());
        
        panel.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        panel.add(generateBtn, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void loadData() {
        model.setRowCount(0);
        ArrayList<Player> players = manager.getAllPlayers();
        
        for (Player p : players) {
            model.addRow(new Object[]{
                p.getPlayerId(),
                p.getName().getFullName(),
                p.getLevel(),
                p.getAge(),
                p.getRoundScore(1),
                p.getRoundScore(2),
                p.getRoundScore(3),
                p.getRoundScore(4),
                p.getRoundScore(5),
                String.format("%.1f", p.getOverallScore())
            });
        }
    }
    
    private void searchPlayer() {
        String idText = searchField.getText().trim();
        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter an ID!");
            return;
        }
        
        try {
            int id = Integer.parseInt(idText);
            Player p = manager.getPlayerById(id);
            
            if (p != null) {
                searchResultArea.setText(
                    "=== FULL DETAILS ===\n\n" +
                    p.getFullDetails() + "\n\n" +
                    "=== SHORT DETAILS ===\n" +
                    p.getShortDetails()
                );
            } else {
                searchResultArea.setText("Player not found!");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Enter a valid number!");
        }
    }
    
    private void generateReport() {
        StringBuilder sb = new StringBuilder();
        ArrayList<Player> players = manager.getAllPlayers();
        
        sb.append("QUIZ COMPETITION REPORT - 5 ROUNDS\n");
        sb.append("===================================\n\n");
        
        sb.append(String.format("%-5s %-15s %-12s %-5s %-5s %-5s %-5s %-5s %-10s\n", 
            "ID", "Name", "Level", "R1", "R2", "R3", "R4", "R5", "Overall"));
        sb.append("--------------------------------------------------------------------\n");
        
        Player top = null;
        double maxScore = -1;
        
        for (Player p : players) {
            sb.append(String.format("%-5d %-15s %-12s %-5d %-5d %-5d %-5d %-5d %-10.1f\n",
                p.getPlayerId(),
                p.getName().getFullName(),
                p.getLevel(),
                p.getRoundScore(1),
                p.getRoundScore(2),
                p.getRoundScore(3),
                p.getRoundScore(4),
                p.getRoundScore(5),
                p.getOverallScore()
            ));
            
            if (p.getOverallScore() > maxScore) {
                maxScore = p.getOverallScore();
                top = p;
            }
        }
        
        sb.append("\nSTATISTICAL SUMMARY:\n");
        sb.append("Total players: ").append(players.size()).append("\n");
        if (top != null) {
            sb.append("Top performer: ").append(top.getName().getFullName())
              .append(" with score ").append(String.format("%.1f", top.getOverallScore())).append("\n");
        }
        
        reportArea.setText(sb.toString());
    }
}