package gui;

import models.Player;

import javax.swing.*;
import java.awt.*;

/**
 * Shows final results after all 5 rounds
 */
public class ResultFrame extends JFrame {
    
    public ResultFrame(Player player, int[] scores) {
        setTitle("Quiz Complete - " + player.getName().getFullName());
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents(player, scores);
    }
    
    private void initComponents(Player player, int[] scores) {
        setLayout(new BorderLayout());
        
        // Title
        JLabel title = new JLabel("QUIZ COMPLETE!", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(new Color(60, 179, 113));
        title.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(title, BorderLayout.NORTH);
        
        // Results panel
        JPanel resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        resultsPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        // Player info
        JLabel nameLabel = new JLabel("Player: " + player.getName().getFullName());
        nameLabel.setFont(new Font("Arial", Font.BOLD, 20));
        resultsPanel.add(nameLabel);
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Round scores
        JLabel roundsTitle = new JLabel("Round Scores:");
        roundsTitle.setFont(new Font("Arial", Font.BOLD, 18));
        resultsPanel.add(roundsTitle);
        
        for (int round = 1; round <= 5; round++) {
            int roundScore = 0;
            int start = (round - 1) * 5;
            for (int i = 0; i < 5; i++) {
                roundScore += scores[start + i];
            }
            
            JLabel roundLabel = new JLabel("  Round " + round + ": " + roundScore + "/5");
            roundLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            resultsPanel.add(roundLabel);
        }
        
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Total score
        int total = 0;
        for (int s : scores) total += s;
        
        JLabel totalLabel = new JLabel("TOTAL: " + total + "/25");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 24));
        totalLabel.setForeground(new Color(70, 130, 180));
        resultsPanel.add(totalLabel);
        
        // Overall score
        double overall = (double) total / 5;
        JLabel overallLabel = new JLabel("Overall Score: " + String.format("%.1f", overall) + "/5.0");
        overallLabel.setFont(new Font("Arial", Font.BOLD, 20));
        resultsPanel.add(overallLabel);
        
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Short details
        player.setScores(scores);
        JLabel shortLabel = new JLabel(player.getShortDetails());
        shortLabel.setFont(new Font("Monospaced", Font.PLAIN, 14));
        resultsPanel.add(shortLabel);
        
        add(resultsPanel, BorderLayout.CENTER);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        
        JButton mainBtn = new JButton("Back to Main");
        mainBtn.setFont(new Font("Arial", Font.BOLD, 16));
        mainBtn.setBackground(new Color(70, 130, 180));
        mainBtn.setForeground(Color.WHITE);
        mainBtn.addActionListener(e -> {
            this.dispose();
            new MainFrame().setVisible(true);
        });
        buttonPanel.add(mainBtn);
        
        JButton newPlayerBtn = new JButton("New Player");
        newPlayerBtn.setFont(new Font("Arial", Font.BOLD, 16));
        newPlayerBtn.setBackground(new Color(60, 179, 113));
        newPlayerBtn.setForeground(Color.WHITE);
        newPlayerBtn.addActionListener(e -> {
            this.dispose();
            new PlayerSetupFrame().setVisible(true);
        });
        buttonPanel.add(newPlayerBtn);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
}