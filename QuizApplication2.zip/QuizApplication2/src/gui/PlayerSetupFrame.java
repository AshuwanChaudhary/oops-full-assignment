package gui;

import models.Player;
import models.Name;

import javax.swing.*;
import java.awt.*;

/**
 * Frame to enter player details before starting quiz
 */
public class PlayerSetupFrame extends JFrame {
    
    private JTextField firstNameField, lastNameField, ageField;
    private JComboBox<String> levelCombo;
    
    public PlayerSetupFrame() {
        setTitle("New Player Registration");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }
    
    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridLayout(5, 2, 15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        mainPanel.add(new JLabel("First Name:"));
        firstNameField = new JTextField();
        mainPanel.add(firstNameField);
        
        mainPanel.add(new JLabel("Last Name:"));
        lastNameField = new JTextField();
        mainPanel.add(lastNameField);
        
        mainPanel.add(new JLabel("Age:"));
        ageField = new JTextField();
        mainPanel.add(ageField);
        
        mainPanel.add(new JLabel("Level:"));
        levelCombo = new JComboBox<>(new String[]{"Beginner", "Intermediate", "Advanced"});
        mainPanel.add(levelCombo);
        
        JButton startBtn = new JButton("Start Round 1");
        startBtn.setFont(new Font("Arial", Font.BOLD, 16));
        startBtn.setBackground(new Color(60, 179, 113));
        startBtn.setForeground(Color.WHITE);
        startBtn.addActionListener(e -> startQuiz());
        mainPanel.add(new JLabel(""));
        mainPanel.add(startBtn);
        
        add(mainPanel);
    }
    
    private void startQuiz() {
        String first = firstNameField.getText().trim();
        String last = lastNameField.getText().trim();
        String ageText = ageField.getText().trim();
        
        if (first.isEmpty() || last.isEmpty() || ageText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }
        
        try {
            int age = Integer.parseInt(ageText);
            String level = (String) levelCombo.getSelectedItem();
            
            Player player = new Player(0, new Name(first, last), level, age);
            
            this.dispose();
            new RoundFrame(player, 1, new int[25]).setVisible(true);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid age!");
        }
    }
}