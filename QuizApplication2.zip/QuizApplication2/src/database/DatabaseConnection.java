package database;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 * Connects to MySQL database Quiz5RoundsDB
 */
public class DatabaseConnection {
    // Database name: Quiz5RoundsDB (different from other projects)
    private static final String URL = "jdbc:mysql://localhost:3306/Quiz5RoundsDB";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static Connection connection = null;
    
    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Database connected!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
                "Cannot connect to database!\nPlease start XAMPP MySQL first.", 
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        return connection;
    }
}