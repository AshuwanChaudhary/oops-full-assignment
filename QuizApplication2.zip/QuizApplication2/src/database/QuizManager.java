package database;

import models.Player;
import models.Question;
import models.Name;

import java.sql.*;
import java.util.ArrayList;

/**
 * Manages all database operations
 */
public class QuizManager {
    
    // Get questions for a specific round (1-5)
    public ArrayList<Question> getQuestionsByRound(int round) {
        ArrayList<Question> questions = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return questions;
        
        try {
            String sql = "SELECT * FROM questions WHERE round_number = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, round);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                questions.add(new Question(
                    rs.getInt("question_id"),
                    rs.getInt("round_number"),
                    rs.getString("question_text"),
                    rs.getString("option_a"),
                    rs.getString("option_b"),
                    rs.getString("option_c"),
                    rs.getString("option_d"),
                    rs.getString("correct_answer").charAt(0)
                ));
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println("Error loading questions: " + e.getMessage());
        }
        return questions;
    }
    
    // Save player to database
    public int savePlayer(Player player) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return 0;
        
        try {
            String sql = "INSERT INTO players (first_name, last_name, level, age) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, player.getName().getFirstName());
            pstmt.setString(2, player.getName().getLastName());
            pstmt.setString(3, player.getLevel());
            pstmt.setInt(4, player.getAge());
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            int playerId = 0;
            if (rs.next()) {
                playerId = rs.getInt(1);
            }
            rs.close();
            pstmt.close();
            return playerId;
        } catch (SQLException e) {
            System.out.println("Error saving player: " + e.getMessage());
            return 0;
        }
    }
    
    // Save quiz results
    public void saveResult(int playerId, int[] scores, double overall) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return;
        
        try {
            String sql = "INSERT INTO quiz_results (player_id, round1_score, round2_score, round3_score, round4_score, round5_score, overall_score) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, playerId);
            pstmt.setInt(2, scores[0] + scores[1] + scores[2] + scores[3] + scores[4]);
            pstmt.setInt(3, scores[5] + scores[6] + scores[7] + scores[8] + scores[9]);
            pstmt.setInt(4, scores[10] + scores[11] + scores[12] + scores[13] + scores[14]);
            pstmt.setInt(5, scores[15] + scores[16] + scores[17] + scores[18] + scores[19]);
            pstmt.setInt(6, scores[20] + scores[21] + scores[22] + scores[23] + scores[24]);
            pstmt.setDouble(7, overall);
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println("Error saving result: " + e.getMessage());
        }
    }
    
    // Get all players with results
    public ArrayList<Player> getAllPlayers() {
        ArrayList<Player> players = new ArrayList<>();
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return players;
        
        try {
            String sql = "SELECT p.*, r.round1_score, r.round2_score, r.round3_score, r.round4_score, r.round5_score FROM players p JOIN quiz_results r ON p.player_id = r.player_id";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Player p = new Player(
                    rs.getInt("player_id"),
                    new Name(rs.getString("first_name"), rs.getString("last_name")),
                    rs.getString("level"),
                    rs.getInt("age")
                );
                
                // Convert round scores back to individual question scores
                int[] scores = new int[25];
                int r1 = rs.getInt("round1_score");
                int r2 = rs.getInt("round2_score");
                int r3 = rs.getInt("round3_score");
                int r4 = rs.getInt("round4_score");
                int r5 = rs.getInt("round5_score");
                
                // Fill scores array (simplified - each question gets average)
                for (int i = 0; i < 5; i++) scores[i] = r1 > i ? 1 : 0;
                for (int i = 5; i < 10; i++) scores[i] = r2 > (i-5) ? 1 : 0;
                for (int i = 10; i < 15; i++) scores[i] = r3 > (i-10) ? 1 : 0;
                for (int i = 15; i < 20; i++) scores[i] = r4 > (i-15) ? 1 : 0;
                for (int i = 20; i < 25; i++) scores[i] = r5 > (i-20) ? 1 : 0;
                
                p.setScores(scores);
                players.add(p);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Error loading players: " + e.getMessage());
        }
        return players;
    }
    
    // Search player by ID
    public Player getPlayerById(int id) {
        Connection conn = DatabaseConnection.getConnection();
        if (conn == null) return null;
        
        try {
            String sql = "SELECT p.*, r.round1_score, r.round2_score, r.round3_score, r.round4_score, r.round5_score FROM players p JOIN quiz_results r ON p.player_id = r.player_id WHERE p.player_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Player p = new Player(
                    rs.getInt("player_id"),
                    new Name(rs.getString("first_name"), rs.getString("last_name")),
                    rs.getString("level"),
                    rs.getInt("age")
                );
                
                int[] scores = new int[25];
                int r1 = rs.getInt("round1_score");
                int r2 = rs.getInt("round2_score");
                int r3 = rs.getInt("round3_score");
                int r4 = rs.getInt("round4_score");
                int r5 = rs.getInt("round5_score");
                
                for (int i = 0; i < 5; i++) scores[i] = r1 > i ? 1 : 0;
                for (int i = 5; i < 10; i++) scores[i] = r2 > (i-5) ? 1 : 0;
                for (int i = 10; i < 15; i++) scores[i] = r3 > (i-10) ? 1 : 0;
                for (int i = 15; i < 20; i++) scores[i] = r4 > (i-15) ? 1 : 0;
                for (int i = 20; i < 25; i++) scores[i] = r5 > (i-20) ? 1 : 0;
                
                p.setScores(scores);
                rs.close();
                pstmt.close();
                return p;
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }
}