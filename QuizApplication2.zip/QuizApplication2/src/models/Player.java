package models;

/**
 * Stores player information and 25 scores (5 rounds x 5 questions)
 */
public class Player {
    private int playerId;
    private Name name;
    private String level;
    private int age;
    private int[] scores;
    
    public Player(int playerId, Name name, String level, int age) {
        this.playerId = playerId;
        this.name = name;
        this.level = level;
        this.age = age;
        this.scores = new int[25];
    }
    
    public int getPlayerId() { return playerId; }
    public Name getName() { return name; }
    public String getLevel() { return level; }
    public int getAge() { return age; }
    public int[] getScores() { return scores; }
    
    public void setScores(int[] scores) { 
        this.scores = scores; 
    }
    
    // Get score for one round (1-5)
    public int getRoundScore(int round) {
        int start = (round - 1) * 5;
        int sum = 0;
        for (int i = start; i < start + 5; i++) {
            sum += scores[i];
        }
        return sum;
    }
    
    // Calculate overall score (average of 25 questions, scaled to 5.0)
    public double getOverallScore() {
        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        return (double) sum / 5; // 25 questions max 5 points, so divide by 5
    }
    
    // Full details format
    public String getFullDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("PlayerID ").append(playerId)
          .append(", name ").append(name.getFullName()).append(".\n")
          .append(name.getFirstName()).append(" is a ").append(level)
          .append(" aged ").append(age).append(" and received these scores:\n");
        
        for (int round = 1; round <= 5; round++) {
            sb.append("Round ").append(round).append(": ");
            int start = (round - 1) * 5;
            for (int i = 0; i < 5; i++) {
                sb.append(scores[start + i]);
                if (i < 4) sb.append(", ");
            }
            sb.append(" (Score: ").append(getRoundScore(round)).append("/5)\n");
        }
        
        sb.append("This gives them an overall score of ")
          .append(String.format("%.1f", getOverallScore())).append(".");
        
        return sb.toString();
    }
    
    // Short details format: CN playerId(initials)has overall score X.X
    public String getShortDetails() {
        return "CN " + playerId + "(" + name.getInitials() + ")has overall score " + 
               String.format("%.1f", getOverallScore());
    }
}